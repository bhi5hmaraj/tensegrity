export const nodeWidth = 360
export const nodeHeight = 200

// Breakpoint for horizontal layout
export const HORIZONTAL_LAYOUT_MIN_WIDTH = 1100
