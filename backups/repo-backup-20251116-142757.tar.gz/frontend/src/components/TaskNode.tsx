import NodeBase from './nodes/NodeBase'

export default function TaskNode(props: any) {
  return <NodeBase {...props} />
}
