import NodeBase from './NodeBase'

export default function BugNode(props: any) {
  return <NodeBase {...props} />
}

