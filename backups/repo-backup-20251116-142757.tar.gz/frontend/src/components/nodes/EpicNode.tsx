import NodeBase from './NodeBase'

export default function EpicNode(props: any) {
  return <NodeBase {...props} />
}

