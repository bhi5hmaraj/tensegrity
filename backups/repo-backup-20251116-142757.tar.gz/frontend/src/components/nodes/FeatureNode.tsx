import NodeBase from './NodeBase'

export default function FeatureNode(props: any) {
  return <NodeBase {...props} />
}

